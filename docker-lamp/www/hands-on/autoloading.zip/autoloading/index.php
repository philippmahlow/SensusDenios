<?php

require __DIR__ . '/vendor/autoload.php';

$test = new \DENIOS\Autoloading\Test\Test();
$test->sayHello();

// separate the classes of example 6 to separate files