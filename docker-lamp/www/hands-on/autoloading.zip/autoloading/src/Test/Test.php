<?php

namespace DENIOS\Autoloading\Test;

class Test
{
    public function sayHello()
{
    echo 'hello';
}
}