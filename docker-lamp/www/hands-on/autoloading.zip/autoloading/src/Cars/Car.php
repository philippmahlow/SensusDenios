<?php

namespace DENIOS\Cars;

use Exception;

class Car
{
    CONST GAS_AMOUNT_PER_DRIVE = 3;

    /**
     * @var string
     */
    protected $color;

    /**
     * @var float
     */
    protected $gasAmount;

    /**
     * Car constructor.
     * @param string $color
     * @param float $gasAmount
     */
    public function __construct(string $color, float $gasAmount)
    {
        $this->color = $color;
        $this->gasAmount = $gasAmount;
    }

    /**
     * @return string
     */
    public function getColor(): string
    {
        return $this->color;
    }

    /**
     * @param string $color
     */
    public function setColor(string $color): void
    {
        $this->color = $color;
    }

    /**
     * @return float
     */
    public function getGasAmount(): float
    {
        return $this->gasAmount;
    }

    /**
     * @param float $gasAmount
     * @throws Exception
     */
    public function setGasAmount(float $gasAmount): void
    {
        if($gasAmount < 0) {
            throw new Exception('Gas amount has to be positive');
        }

        $this->gasAmount = $gasAmount;
    }


    public function drive(Driver $driver)
    {
        // implement method. The gas amount should be deducted by the defined amount per drive.
        $gasAmount = self::GAS_AMOUNT_PER_DRIVE;

        if($driver->isFast()) {
            $gasAmount *= 2;
        }

        $this->setGasAmount($this->getGasAmount() - $gasAmount);
    }

}