<?php


namespace DENIOS\Cars;


class Driver {

    /**
     * @var string
     */
    protected $name;

    /**
     * @var bool
     */
    protected $isFast;

    /**
     * Driver constructor.
     * @param string $name
     * @param bool $isFast
     */
    public function __construct(string $name, bool $isFast)
    {
        $this->name = $name;
        $this->isFast = $isFast;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return bool
     */
    public function isFast(): bool
    {
        return $this->isFast;
    }

    /**
     * @param bool $isFast
     */
    public function setIsFast(bool $isFast): void
    {
        $this->isFast = $isFast;
    }



}